import { checkForName } from './js/nameChecker'
import { handleSubmit } from './js/formHandler'
import { getMCAPI } from './js/postRequest'


import "./styles/main.scss";

export {
    checkForName,
    handleSubmit,
    getMCAPI
}
   

