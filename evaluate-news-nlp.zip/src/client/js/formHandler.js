function handleSubmit(event) {
    event.preventDefault()

    // check what text was put into the form field
    let formText = document.getElementById('name').value
    if (Client.checkForName(formText)) {
        let data = {};
        data['text'] = formText;    
        console.log("::: Form Submitted :::");
        Client.getMCAPI(data)
        .then(function(res) {
            console.log(res);
            document.getElementById('results').innerHTML = JSON.stringify(res);
        })
    }
}

export { handleSubmit }
