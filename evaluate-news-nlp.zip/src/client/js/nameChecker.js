function checkForName(inputText) {
    console.log('::: Running checkForName :::', inputText);
    var reg = /^[A-Za-z\d\s]+$/;
    console.log('Regex test.');
    if (!reg.test(inputText + "\n")) {
        document.getElementById('results').innerHTML = 'Please, enter correct request.';
        return false;
    };  
    return true;
}

export { checkForName }
