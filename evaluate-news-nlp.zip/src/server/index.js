var path = require('path');
const express = require('express');
var webpack = require('webpack');
var webpackConfig = require('../../webpack.prod');
var compiler = webpack(webpackConfig);
const https = require('https');
const querystring = require('querystring');
require("dotenv").config();

const KEY = process.env.KEY;

const app = express();

app.use(express.static("dist"));

app.use(express.json());
app.use(require("webpack-dev-middleware")(compiler, {
    noInfo: true, publicPath: '../../dist'
}));
app.use(require("webpack-hot-middleware")(compiler));

var options = {
    host: 'api.meaningcloud.com',
    path: '/sentiment-2.1',
    port: 443,
    method: 'POST',
    headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
    } 
  };  

app.get('/', function (req, res) {
    res.sendFile('dist/index.html')
});

// designates what port the app will listen to for incoming requests
app.listen(8081, function () {
    console.log('Sentiment analysis app is listening on port 8081!')
});

app.post('/sentiment', function (req, res) {
    let data = {};
    data['key'] = KEY;
    data['txt'] = req.body.text;
    data['lang'] = 'en';    
    var request = https.request(options);  
    request.write(querystring.stringify(data));
    request.on('response', function (response) {
        response.on('data', function (chunk) {
            var json = JSON.parse(chunk.toString());
            console.log(json);
            res.send(chunk);        
       });
      });      
    request.on('error', (e) => {
        console.error(e);
      });
    request.end();        
});