# Sentiment Analysis App

## Overview
An app can make text sentiment predictions using Meaning Cloud API.

## Instructions
1. Install NodeJS.
```
sudo apt install nodejs
```
2. Install npm.
```
sudo apt install npm
```
3. Install dependencies.
```
npm install
```
4. Run in Development Mode.
```
npm run build-dev
```
5. Run in Production Mode.
```
npm run build-prod
```
6. You can run Unit Tests.
```
npm run test
```

## Comments
I used nodemon to avoid reloading NodeJS server after save.
