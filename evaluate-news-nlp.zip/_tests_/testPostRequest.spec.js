import { getMCAPI } from "../src/client/js/postRequest"
describe("Testing the submit functionality", () => {
    test("Testing the handleSubmit() function", () => {
           expect(getMCAPI).toBeDefined();
})});
