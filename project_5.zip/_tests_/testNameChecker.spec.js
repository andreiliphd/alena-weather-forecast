import { checkForName } from "../src/client/js/nameChecker"
describe("Testing the checking input date functionality", () => {
    test("Testing the checkForName() function", () => {
           expect(checkForName).toBeDefined();
})});
