import { getAPI } from "../src/client/js/postRequest"
describe("Testing the POST request functionality", () => {
    test("Testing the getAPI() function", () => {
           expect(getAPI).toBeDefined();
})});
